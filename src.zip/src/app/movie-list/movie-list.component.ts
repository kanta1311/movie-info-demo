import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MoviesService } from '../service/movies.service';
import { movieInterface } from './_interface/movie.interface';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {

  @Input() movieListData: movieInterface[] = [];
  @Output() movieItemSelectedEvent = new EventEmitter<movieInterface>();
  selectedId: number | undefined;
  constructor(public movieService: MoviesService) {
    this.movieListData = this.movieService.list();
  }

  ngOnInit(): void {

  }

  onClick(movie: movieInterface) {
    this.movieItemSelectedEvent.emit(movie);
    this.selectedId = movie.id;
  }

}
