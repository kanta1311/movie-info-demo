export interface movieInterface {
  id: number,
  title: string,
  imageUrl: string,
  director: string,
  casts: string
}
